import React from "react";
import styles from "./app.module.scss"; 
import TopBar from "./components/Top Bar/TopBar";
import Header from "./components/Header/Header";
import  Services from "./components/Services/Services";
import Hero from "./components/Hero/Hero";
import Hero2 from "./components/Hero2/Hero2";
import Hero3 from "./components/Hero3/Hero3";
import Stats from "./components/Stats/Stats";
import Hero4 from "./components/Hero4/Hero4";
import Contact from "./components/Contact/Contact";
import Footer from "./components/Footer/Footer";
import ScrollTop from "./components/ScrollTop/ScrollTop";

const Layout = () => {
  return (
    <div className={styles.page}>
      <TopBar />

      <div className={styles.container}>
        <Header />
        <Services />
        <Hero />
        <Hero2 />
        <Hero3 />
        <Stats />
        <Hero4 />
        <Contact />
        <ScrollTop />

      </div>

      <Footer />
    </div>
  );
};

export default Layout;