import React from "react";
import operatorsImage from "../../assets/picture/operators.png"; 
import "./Hero4.scss";

const Hero4 = () => {
  return (
    <section className="hero3">
      <div className="container hero-grid">
        <div className="hero-left">
          <h4>Հարկավոր է տեքստ</h4>
          <h1>Հարկավոր է տեքստ</h1>
          <p>
            Mobile ID-ն անձի նույնականացման, ինչպես նաև էլեկտրոնային 
            եղանակով ստորագրելու հարթակ է: Համակարգը հնարավորություն է 
            տալիս ստորագրել ցանկացած փաստաթուղթ առանց հավելյալ ջանքերի:
          </p>
          <button className="btn-primary">Իմանալ ավելին</button>
        </div>

        <div className="hero-right">
          <div className="hero-image">
            <img src={operatorsImage} alt="Operators Illustration" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero4;