import React from "react";
import "./Header.scss";
import firmaLogo from "../../assets/logo/firma.png";
import girlImage from "../../assets/picture/girl1.png";
import pause from "../../assets/picture/pause.png";
import facebookLogo from "../../assets/logo/facebookLogo.png";
import vivaLogo from "../../assets/logo/vivaLogo.png";
import gmailLogo from "../../assets/logo/gmailLogo.png";
import teamLogo from "../../assets/logo/teamLogo.png";
import eurovisionLogo from "../../assets/logo/eurovisionLogo.png";
import ucomLogo from "../../assets/logo/ucomLogo.png";

const Header = () => {
  return (
    <>
      <header className="header">
        <div className="container header-inner">
          <div className="logo">
            <img src={firmaLogo} alt="Firma logo" />
          </div>

          <nav className="nav">
            <a href="#">Մեր ծառայությունները</a>
            <a href="#">Ինչպես է աշխատում</a>
            <a href="#">Առավելություններ</a>
            <a href="#">Կապ մեզ հետ</a>
          </nav>

          <div className="header-actions">
            <div className="circle-btn lang">
                               ՀՅ
                     <div className="lang-dropdown">
                           <div>RUS</div>
                             <div>ENG</div>
                                   </div>
                                </div>
            <div className="circle-btn phone">+374 55 12 34 56</div>
          </div>
        </div>
      </header>

      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-left">
            <h1>
              Խելացի մարքեթինգ,<br />
              Ձեր բիզնեսի համար 💡
            </h1>

            <p>
              Ուղարկեք զանգվածային SMS և WEB հաղորդագրություններ
              արագ և արդյունավետ։
            </p>

            <div className="hero-actions">
              <button className="btn-primary">Կապ մեզ հետ</button>
               <img src={pause} alt="Pause Image" />
            </div>
          </div>

          <div className="hero-right">
            <div className="hero-image">
              <img src={girlImage} alt="Hero Girl" />
            </div>

            <div className="badge badge-users">500+</div>
            <div className="badge badge-sms">SMS</div>
            <div className="badge badge-like">❤</div>
          </div>
        </div>

        <p className="hero-center">
          Միացե՛ք արդեն աճող 4000+ ընկերություններին
        </p>
      </section>

      <section className="partners">
        <div className="container partners-inner">
           <div className="partner"><img src={facebookLogo} alt="Facebook" /></div>
    <div className="partner"><img src={vivaLogo} alt="Viva" /></div>
    <div className="partner"><img src={gmailLogo} alt="Gmail" /></div>
    <div className="partner"><img src={teamLogo} alt="Team" /></div>
    <div className="partner"><img src={eurovisionLogo} alt="Eurovision" /></div>
    <div className="partner"><img src={ucomLogo} alt="Ucom" /></div>
        </div>
      </section>
    </>
  );
};


export default Header;