import React from "react";
import "./Contact.scss";

const Contact = () => {
  return (
    <section className="contact">
      <div className="container contact-inner">

        <div className="contact-container">

         
          <div className="contact-form">
            <h2>Կապ մեզ հետ</h2>
            <p>Մենք տրամադրում ենք շուրջօրյա ծառայություն, խնդրում ենք զանգահարել 0105128888:</p>

            <form>
              <div className="row">
                <input type="text" placeholder="Անուն *" required />
                <input type="text" placeholder="Ազգանուն *" required />
              </div>

              <input type="text" placeholder="Էլ․ փոստ *" required />

              <div className="phone-row">
                <select>
                  <option value="+374">🇦🇲 +374</option>
                </select>
                <input type="tel" placeholder="552123456" required />
              </div>

              <textarea placeholder="Հաղորդագրություն"></textarea>

              <div className="checkboxes">
                <label><input type="checkbox" /> SMS ծանուցումներ</label>
                <label><input type="checkbox" /> Զանգահարել հետո</label>
                <label><input type="checkbox" /> Առաքում / այցի հարց</label>
                <label><input type="checkbox" /> Այլ</label>
              </div>

              <button type="submit">Ուղարկել</button>
            </form>
          </div>

          
          <div className="contact-map">
            <iframe
              src="https://www.google.com/maps?q=Yerevan&output=embed"
              allowFullScreen
              loading="lazy"
              title="Map"
            ></iframe>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;