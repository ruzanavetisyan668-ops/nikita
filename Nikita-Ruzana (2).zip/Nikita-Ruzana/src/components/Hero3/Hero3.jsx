import React from "react";
import hecoImage from "../../assets/picture/heco.png";
import "./Hero3.scss";

const Hero3 = () => {
  return (
    <section className="hero3">
      <div className="container hero-grid">
        <div className="hero-left">
          <h1>Ստացիր Քո մրցանակը</h1>
          <p>
            Mobile ID-ն անձի նույնականացման, ինչպես նաև էլեկտրոնային եղանակով
            ստորագրելու հարթակ է: Համակարգը հնարավորություն է տալիս ստորագրել 
            ցանկացած փաստաթուղթ առանց հավելյալ ջանքերի:
          </p>
          <button className="btn-primary">Իմանալ ավելին</button>
        </div>

        <div className="hero-right">
          <div className="hero-image">
            <img src={hecoImage} alt="Reward Illustration" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero3;