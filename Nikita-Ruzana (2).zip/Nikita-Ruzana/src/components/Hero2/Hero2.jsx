import React from "react";
import inpImage from "../../assets/picture/inp.png";
import "./Hero2.scss";

const Hero2 = () => {
  return (
    <section className="hero2">
      <div className="container hero-grid">
        <div className="hero-right">
          <div className="hero-image">
            <img src={inpImage} alt="Input Illustration" />
          </div>
        </div>

        <div className="hero-left">
          <h1>
            Մուտքագեք ծածկագիրը մեր պլատֆորմում
          </h1>
          <p>
            Mobile ID-ն անձի նույնականացման, ինչպես նաև էլեկտրոնային եղանակով
            ստորագրելու հարթակ է: Համակարգը հնարավորություն է տալիս ստորագրել 
            ցանկացած փաստաթուղթ առանց հավելյալ ջանքերի:
            Ուղարկել SMS կարճ համարին
            Ուղարկել կոդը "պլատֆորմով"
          </p>

          <div className="hero-actions">
            <button className="btn-primary">Իմանալ ավելին</button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero2; 