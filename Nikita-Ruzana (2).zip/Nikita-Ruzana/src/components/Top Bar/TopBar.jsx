
import React from "react";
import "./TopBar.scss";

const TopBar = () => {
  return (
    <div className="top-bar">
      <p>
        Հատուկ առաջարկ 🔥 Բարձրացրեք Ձեր փորձառությունը Nikita-ի հետ{" "}
        <a href="#">Տեսնել ավելին →</a>
      </p>
    </div>
  );
};

export default TopBar;