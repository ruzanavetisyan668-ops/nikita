import React from "react";
import "./Hero.scss";
import boyImage from "../../assets/picture/boy2.png"; 

const Hero = () => {
  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-left">
            <h1>
              Գտիր ծածկագիրը
              <br />
              խցանի տակ
            </h1>

            <p>
              Mobile ID-ն անձի նույնականացման, ինչպես նաև էլեկտրոնային
              եղանակով ստորագրելու հարթակ է։
            </p>

            <button className="btn-primary">Իմանալ ավելին</button>
          </div>

          <div className="hero-right">
            <div className="hero-image">
              <img src={boyImage} alt="Boy" />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Hero;