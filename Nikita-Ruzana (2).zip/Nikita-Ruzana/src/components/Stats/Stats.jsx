import React from "react";
import "./Stats.scss";

const Stats = () => {
  return (
    <section className="stats">
      <div className="container stats-inner">
        <div>
          <h2>180+</h2>
          <p>Countries Supported</p>
        </div>
        <div>
          <h2>40K+</h2>
          <p>Affiliates</p>
        </div>
        <div>
          <h2>$7M</h2>
          <p>Commissions Paid</p>
        </div>
      </div>
    </section>
  );
};

export default Stats;