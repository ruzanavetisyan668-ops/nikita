import React from "react";
import "./Footer.scss";
import instagram from "../../assets/logo/social_logos.png";
import facebook from "../../assets/logo/social_logos (1).png";
import linkedIn from "../../assets/logo/social_logos (2).png";
import youtube from "../../assets/logo/social_logos (3).png";
import tikTok from "../../assets/logo/social_logos (4).png";
export default  function Footer () {

  return <footer className="footer">
    <div className="footer-inner">
      <div className="footer-text">
        <p>© 2025 Nikita LLC․</p>
        <p>Բոլոր իրավունքները պաշտպանված են</p>
      </div>
      <div className="socials">
         <a href="#"><img src={instagram} alt="Instagram" /></a>
  <a href="#"><img src={facebook} alt="Facebook" /></a>
  <a href="#"><img src={linkedIn} alt="LinkedIn" /></a>
  <a href="#"><img src={youtube} alt="Youtube" /></a>
  <a href="#"><img src={tikTok} alt="TikTok" /></a>
      </div>
    </div>
  </footer>
};
