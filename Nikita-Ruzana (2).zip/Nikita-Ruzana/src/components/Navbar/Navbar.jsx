import React from "react";
import styles from "./Navbar.module.scss";

const Navbar = () => (
  <header className={styles.header}>
    <div className={styles.container}>
      <div className={styles.logo}>
        <img src="logo/firma.png" alt="Firma logo" />
      </div>

      <nav className="nav">
        <a href="#services">Մեր ծառայությունները</a>
        <a href="#how-it-works">Ինչպես է աշխատում</a>
        <a href="#benefits">Առավելություններ</a>
        <a href="#contact">Կապ մեզ հետ</a>
      </nav>

      <div className="header-actions">
        <div className="circle-btn lang">ՀՅ</div>
        <div className="circle-btn phone">+374 55 12 34 56</div>
      </div>
    </div>
  </header>
);

export default Navbar;