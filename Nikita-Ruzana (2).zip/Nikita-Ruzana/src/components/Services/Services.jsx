import React from "react";
import "./Services.scss";
import card1 from "../../assets/picture/card1.png";
import card2 from "../../assets/picture/card2.png";
import card3 from "../../assets/picture/card3.png";

const Services = () => (
  <section className="services" id="services">
    <div className="container services-inner">
      <div className="service-card">
        <div className="Card">
          <img src={card1} alt="Card" />
        </div>
        <h3>ՍՄՍ և ՎԵԲ</h3>
        <p>Բաժանորդներին հնարավորություն է տրվում հաղորդագրություն ուղարկել և՛ SMS-ի միջոցով, և՛ WEB կայքով:</p>
      </div>

      <div className="service-card">
        <div className="Card">
          <img src={card2} alt="Card" />
        </div>
        <h3>ՎԵԲ</h3>
        <p>Բաժանորդներին հնարավորություն է տրվում հաղորդագրություն ուղարկել միայն WEB-ի միջոցով:</p>
      </div>

      <div className="service-card">
        <div className="Card">
          <img src={card3} alt="Card" />
        </div>
        <h3>ՍՄՍ</h3>
        <p>Բաժանորդներին հնարավորություն է տրվում հաղորդագրություն ուղարկել միայն SMS-ի միջոցով:</p>
      </div>
    </div>
  </section>
);

export default Services;