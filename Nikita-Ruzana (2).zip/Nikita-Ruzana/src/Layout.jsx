import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import Navbar from "./components/Navbar/Navbar";
import React from "react";


export default function Layout() {

    '//TODO:mnacac hatvac@ headeri u footer michev pedqa lini componentnerov'

    return <div>
        <Header/>
        <Navbar/>

        <Footer/>
    </div>
}